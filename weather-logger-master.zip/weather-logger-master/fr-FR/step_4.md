--- challenge ---

## Défi : Simuler différentes conditions météo

Peux-tu collecter et afficher la météo pour différentes conditions météorologiques? Essaye une chaude journée d'été où la température est supérieure à 30 degrés Celsius et un jour d'hiver froid où la température descend en dessous de zéro.

N'oublie pas que tu devras permuter entre inclure `collecter` et `affichage` dans `main.py` .

Tu peux juste mettre en surbrillance les données et les supprimer dans `weather.txt` pour effacer les données. Ou tu peux créer de nouveaux fichiers pour stocker différentes lectures.

--- /challenge ---