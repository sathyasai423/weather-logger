--- challenge ---

## Défi : Enregistre l'humidité ou la pression

Le taux d'humidité est élevé lorsqu'il y a beaucoup d'humidité dans l'air. La haute pression est associée à un beau temps tandis que la basse pression signifie un temps nuageux, pluvieux ou enneigé.

Duplique ton projet et modifie-le pour qu'il enregistre l'humidité ou la pression au lieu de la température.

--- /challenge ---

***

"Ce projet a été traduit par des bénévoles:

Eric Verplanken
Michel Arnols

Grâce aux bénévoles, nous pouvons donner aux gens du monde entier la chance d'apprendre dans leur propre langue. Vous pouvez nous aider à atteindre plus de personnes en vous portant volontaire pour la traduction - plus d'informations sur [rpf.io/translate](https://rpf.io/translate)."