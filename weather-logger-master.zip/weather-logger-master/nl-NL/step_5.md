--- challenge ---

## Uitdaging: registreer de vochtigheid of druk

De luchtvochtigheid is hoog als er veel vocht in de lucht is. Hoge druk wordt geassocieerd met mooi weer, terwijl lage druk betekent bewolkt, regenachtig of sneeuwweer.

Dupliceer je project en verander het zodat het de vochtigheid of druk registreert in plaats van de temperatuur.

--- /challenge ---

***
Dit project werd vertaald door vrijwilligers:

Coen Warries
Sanneke van der Meer
Robert-Jan Kempenaar

Dankzij vrijwilligers kunnen we mensen over de hele wereld de kans geven om in hun eigen taal te leren. Jij kunt ons helpen meer mensen te bereiken door vrijwillig te starten met vertalen - meer informatie op [rpf.io/translate](https://rpf.io/translate).