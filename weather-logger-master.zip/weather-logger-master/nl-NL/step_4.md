--- challenge ---

## Uitdaging: simuleer verschillende weersomstandigheden

Kun je het weer verzamelen en weergeven voor verschillende weersomstandigheden? Probeer een hete zomerdag waar de temperatuur meer dan 30 graden C is en een koude winter waar de temperatuur onder het vriespunt daalt.

Onthoud dat je moet wisselen tussen `collect` en `display` in `main.py`.

Je kunt de gegevens in `weather.txt` markeren en verwijderen om de gegevens te wissen. Of je kunt een nieuw bestand maken om verschillende metingen op te slaan.

--- /challenge ---