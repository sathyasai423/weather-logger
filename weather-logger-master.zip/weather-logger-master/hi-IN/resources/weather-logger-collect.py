from sense_hat import SenseHat
from time import sleep

समझ = संवेदना ()



