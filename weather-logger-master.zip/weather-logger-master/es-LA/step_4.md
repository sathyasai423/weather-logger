--- challenge ---

## Desafío: Simular diferentes condiciones climáticas

¿Puedes recopilar y mostrar el tiempo para diferentes condiciones meteorológicas? Prueba un caluroso día de verano donde la temperatura supere los 30 grados C y un invierno frío donde la temperatura descienda por debajo de cero.

Recuerda que tendrás que intercambiar entre `collect` y `display` en `main.py`.

Sólo puedes resaltar y eliminar los datos en `weather.txt` para borrar los datos. O podrías crear nuevos archivos para almacenar diferentes lecturas.

--- /challenge ---