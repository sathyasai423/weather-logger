--- challenge ---

## Desafío: Registrar humedad o presión

La humedad es alta cuando hay mucha humedad en el aire. La alta presión está asociada con el buen tiempo, mientras que la baja presión significa un clima nublado, lluvioso o nevado.

Duplica tu proyecto y cámbialo para que registre la humedad o la presión en lugar de la temperatura.

--- /challenge ---


***
Este proyecto fue traducido por voluntarios:

Rocio Abad Vergara

Kelly Gisele Pedroza Delgado

Verónica Valencia Límaco

Gracias a los voluntarios, podemos dar a las personas de todo el mundo la oportunidad de aprender en su propio idioma. Puedes ayudarnos a llegar a más personas ofreciéndote como voluntario para traducir. Más información en [rpf.io/translate](https://rpf.io/translate).