--- challenge ---

## Challenge: Record humidity or pressure

 Humidity is high when there is a lot of moisture in the air. High pressure is associated with fine weather while low pressure means cloudy, rainy or snowy weather. 

Duplicate your project and change it so that it records humidity or pressure instead of temperature.

--- /challenge ---