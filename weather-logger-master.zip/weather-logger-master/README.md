# weather-logger

Don't forget to update the project name in LICENSE.md
